# Confident sources

*   total number of sources above $3\sigma$ : 54770
*   Number of AGN

| class |  number |
|:-------|--------:|
| AGN    |   32600 |
| STAR   |   16148 |
| YSO    |    5184 |
| HMXB   |     439 |
| LMXB   |     197 |
| CV     |      89 |
| PULSAR |      63 |
| ULX    |      50 |

![feat_imp](result/plots/feat_imp.jpg)

![coord_sep](result/plots/feature_sep/important_features/gal_coord.png)

<table>
    <tr>
        <td><img src = ''>
    </tr>
</table>



![coord_sep](result/plots/feature_sep/important_features/b-mag.jpg)

![coord_sep](result/plots/feature_sep/important_features/m-mag.jpg)


![coord_sep](result/plots/feature_sep/important_features/h-mag.jpg)


![coord_sep](result/plots/feature_sep/important_features/u-mag.jpg)